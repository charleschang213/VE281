/*************************************************************************
    > File Name: clocking.h
    > Author: Charles Chang
    > Mail: charleschang213@sjtu.edu.cn 
    > Created Time: 2018-09-21 03:02:56
 ************************************************************************/
#ifndef CLOCKING_H
#define CLOCKING_H
#include "sorting.h"
void clocking_main();
#endif
